# ScriptForge Portable for Windows

1. Extract the entire ZIP to a short, writable path such as `C:\ScriptForge`. Avoid running from the ZIP preview or from a synced folder.
2. Double-click **Start-ScriptForge.cmd**. Leave the console open while it downloads the local runtimes and models. First launch needs internet, several gigabytes of downloads, and roughly 13 GB of free disk space. Windows x64 is the supported target.
3. The launcher opens the local UI at **http://127.0.0.1:8766/**. On later launches, it reuses the files already downloaded. No separate installers or administrator rights are needed.

## Make a video

- **Story** finds and reads relevant public pages, then uses the bundled workflow and a local Ollama model to draft and check the script. Review the sources before publishing. Automatic source discovery needs internet access.
- **Voiceover** defaults to the offline Kokoro Documentary Blend, a 78% Michael / 22% Fenrir blend using the full-precision model. Piper is also available offline. Both need no key. It also accepts uploaded audio. Gemini and ElevenLabs are optional and use your own keys.
- **Render** uses local Whisper captions, GrowKaz visual and sound templates, Three.js, Remotion, and FFmpeg. The MP4 appears in **outputs** and in the browser preview.

Close the launcher when finished. App jobs and research data live in **work**, and downloaded runtimes and models live in **.runtime** or the workspace's dependency folders. The current draft is stored by the browser for this local address. Copy the extracted folder to move its files. Copy any narration draft from the UI separately when moving between browsers or PCs.

The ZIP contains application code and setup scripts. It excludes API keys, prior projects, recordings, videos, and third-party runtime binaries. The first launch downloads those dependencies from their publishers. Check the terms of the supplied GrowKaz toolkit and third-party model and runtime licenses before redistributing or using the package commercially.

## Update an earlier portable copy

Extract this ZIP over the same ScriptForge folder and allow the ZIP files to replace the earlier app files. Run the launcher again. It will install the Kokoro dependencies and download the new voice assets. Existing data and downloaded runtimes live in separate paths from the ZIP files.

## If setup is interrupted

Run the launcher again. Completed downloads and setup steps are reused. The console reports setup errors. If Ollama fails to start, see **.runtime/ollama.log**. The app uses loopback ports 8766 and 11436.
