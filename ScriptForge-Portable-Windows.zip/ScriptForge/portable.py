"""Prepare and run the portable Windows workspace."""
import json
import os
import shutil
import stat
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RT = ROOT / '.runtime'
APP = ROOT / 'outputs/ScriptForge'
RENDERER = ROOT / 'outputs/three-remotion'
KIT = ROOT / 'work/growkaz-stickman-studio'
MODEL = 'qwen2.5:3b'
OLLAMA_HOST = '127.0.0.1:11436'
VOICE_MODELS = ['en_US-ryan-high', 'en_US-hfc_male-medium']
NODE_VERSION = '24.11.1'
OLLAMA_VERSION = '0.40.17'
PACKAGES = ('numpy==2.5.5', 'scipy==1.18.1', 'faster-whisper==1.2.1', 'piper-tts==1.8.0',
            'kokoro-onnx==0.6.1', 'soundfile==0.14.0')
UA = {'User-Agent': 'ScriptForgePortable/1.0'}

def say(message):
    print(message, flush=True)

def get(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as response:
        return json.load(response)

def download(url, path):
    if path.is_file():
        return
    say('Downloading ' + path.name)
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix+'.part')
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=90) as response:
        with partial.open('wb') as output:
            shutil.copyfileobj(response, output, length=1024*1024)
    partial.replace(path)

def archive(url, name, executable):
    target = RT/name
    candidates = list(target.rglob(executable)) if target.is_dir() else []
    if candidates:
        return candidates[0]
    zip_path = RT/'downloads'/(name+'.zip')
    download(url,zip_path)
    pending = RT/(name+'-extracting')
    if pending.exists():
        shutil.rmtree(pending)
    pending.mkdir()
    with zipfile.ZipFile(zip_path) as package:
        for entry in package.infolist():
            resolved=(pending/entry.filename).resolve()
            if not resolved.is_relative_to(pending.resolve()) or stat.S_ISLNK(entry.external_attr >> 16):
                raise ValueError('Unexpected path in '+name+' archive')
        package.extractall(pending)
    if not any(pending.rglob(executable)):
        raise ValueError('Missing executable in '+name+' archive')
    if target.exists():
        shutil.rmtree(target)
    pending.rename(target)
    zip_path.unlink()
    return next(target.rglob(executable))

def run(args, env=None, cwd=ROOT):
    subprocess.run([str(arg) for arg in args], env=env, cwd=cwd, check=True)

def python_packages(env):
    py = Path(sys.executable)
    pth = py.with_name('python312._pth')
    if pth.exists():
        text = pth.read_text(encoding='utf-8')
        if '#import site' in text:
            pth.write_text(text.replace('#import site','import site'),encoding='utf-8')
    site = py.parent/'Lib/site-packages'
    site.mkdir(parents=True,exist_ok=True)
    marker = site/'.scriptforge-ready-v2'
    if marker.exists():
        return
    if not (site/'pip').exists():
        installer = RT/'downloads/get-pip.py'
        download('https://bootstrap.pypa.io/get-pip.py',installer)
        run([py,installer,'--no-warn-script-location','--disable-pip-version-check'],env)
    say('Installing local transcription, sound, Piper and Kokoro packages')
    run([py,'-m','pip','install','--disable-pip-version-check','--no-warn-script-location',*PACKAGES],env)
    run([py,'-c','import numpy, scipy, faster_whisper, piper, kokoro_onnx, soundfile'],env)
    marker.touch()

def prepare_renderer(node,env):
    npm = node.parent/'node_modules/npm/bin/npm-cli.js'
    pnpm_root = RT/'package-manager'
    pnpm = pnpm_root/'node_modules/pnpm/bin/pnpm.cjs'
    cli = RENDERER/'node_modules/@remotion/cli/remotion-cli.js'
    if not cli.is_file():
        if not pnpm.is_file():
            run([node,npm,'install','--prefix',pnpm_root,'--no-audit','--no-fund','pnpm@11.25.0'],env)
        say('Installing locked Remotion and Three.js dependencies')
        run([node,pnpm,'install','--frozen-lockfile','--store-dir',RT/'pnpm-store'],env,RENDERER)

def find_chrome():
    candidates = [Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Google/Chrome/Application/chrome.exe',
                  Path(os.environ.get('ProgramFiles(x86)','C:/Program Files (x86)'))/'Microsoft/Edge/Application/msedge.exe']
    for path in candidates:
        if path.is_file():
            return path
    portable = next(iter((RT/'chromium').rglob('chrome.exe')),None)
    if portable:
        return portable
    manifest = get('https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json')
    url = next(item['url'] for item in manifest['channels']['Stable']['downloads']['chrome'] if item['platform']=='win64')
    return archive(url,'chromium','chrome.exe')

def setup_models(env):
    cache = KIT/'.whisper-cache'
    marker = cache/'.scriptforge-base-en-ready'
    if not marker.exists():
        say('Downloading the local Whisper base.en model')
        run([sys.executable,'-c','from faster_whisper.utils import download_model; download_model("base.en")'],env)
        marker.touch()
    voices = RT/'voices'
    if not all((voices/(name+ext)).is_file() for name in VOICE_MODELS for ext in ('.onnx','.onnx.json')):
        say('Downloading two local Piper voices')
        voices.mkdir(exist_ok=True)
        run([sys.executable,'-m','piper.download_voices','--data-dir',voices,*VOICE_MODELS],env)

def setup_kokoro():
    release = 'https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.1/'
    for name in ('kokoro-v1.0.onnx', 'voices-v1.0.bin'):
        download(release + name, RT/'kokoro'/name)

def start_ollama(ollama,env):
    log = RT/'ollama.log'
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    endpoint = 'http://'+OLLAMA_HOST
    def ready():
        try:
            with opener.open(endpoint+'/api/tags',timeout=2) as response:
                return 'models' in json.load(response)
        except (OSError, ValueError):
            return False
    if ready():
        return None
    with log.open('a',encoding='utf-8') as output:
        proc = subprocess.Popen([str(ollama),'serve'],cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    for _ in range(45):
        if ready():
            return proc
        if proc.poll() is not None:
            break
        time.sleep(1)
    if proc.poll() is None:
        proc.terminate()
    raise RuntimeError('Local Ollama did not start. See .runtime/ollama.log.')

def main():
    if os.name!='nt' or os.environ.get('PROCESSOR_ARCHITECTURE','').upper() not in {'AMD64','ARM64'}:
        raise RuntimeError('Use this ZIP on Windows x64.')
    RT.mkdir(exist_ok=True)
    env=dict(os.environ, PIP_CACHE_DIR=str(RT/'pip-cache'), npm_config_cache=str(RT/'npm-cache'),
             OLLAMA_MODELS=str(RT/'ollama-models'), OLLAMA_HOST=OLLAMA_HOST, OLLAMA_NO_CLOUD='1',
             SCRIPTFORGE_OLLAMA='http://'+OLLAMA_HOST, SCRIPTFORGE_PORT='8766',
             HF_HOME=str(KIT/'.whisper-cache'), HF_HUB_DISABLE_SYMLINKS_WARNING='1',
             SCRIPTFORGE_PIPER_VOICES=str(RT/'voices'))
    env.pop('HF_HUB_OFFLINE',None)
    node=archive(f'https://nodejs.org/dist/v{NODE_VERSION}/node-v{NODE_VERSION}-win-x64.zip','node','node.exe')
    ffmpeg=archive('https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip','ffmpeg','ffmpeg.exe')
    env['PATH']=os.pathsep.join([str(node.parent),str(ffmpeg.parent),env.get('PATH','')])
    env['SCRIPTFORGE_BROWSER']=str(find_chrome())
    python_packages(env)
    prepare_renderer(node,env)
    setup_models(env)
    setup_kokoro()
    ollama=archive(f'https://github.com/ollama/ollama/releases/download/v{OLLAMA_VERSION}/ollama-windows-amd64.zip',
                   'ollama','ollama.exe')
    proc=start_ollama(ollama,env)
    try:
        local=subprocess.check_output([str(ollama),'list'],env=env,text=True)
        if not any(row.split() and row.split()[0] == MODEL for row in local.splitlines()):
            say('Downloading the local story model '+MODEL)
            run([ollama,'pull',MODEL],env)
        say('Opening ScriptForge at http://127.0.0.1:8766/')
        run([sys.executable,APP/'server.py','--open'],env)
    finally:
        if proc is not None and proc.poll() is None:
            proc.terminate()
            proc.wait(timeout=12)

if __name__=='__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
    except (OSError, RuntimeError, subprocess.SubprocessError, ValueError) as error:
        sys.exit(str(error))
