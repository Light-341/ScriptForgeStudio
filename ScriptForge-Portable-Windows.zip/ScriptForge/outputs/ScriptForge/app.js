'use strict';
const get = id => document.getElementById(id);
const value = id => get(id).value.trim();
const draftFields = ['model','length','niche','topic','title','narration','shots','provider','localVoice','geminiVoice','voiceId','voiceModel','style','mood'];
const draft = (() => {
  try { return JSON.parse(localStorage.getItem('scriptforge-draft') || '{}'); }
  catch { return {}; }
})();
let token = '';
let audio = null;
let exportFile = null;
let sources = Array.isArray(draft.sources) ? draft.sources : [];

function stash() {
  const saved = Object.fromEntries(draftFields.map(id => [id, get(id).value]));
  localStorage.setItem('scriptforge-draft', JSON.stringify({...saved,audio,exportFile,sources,sound:get('sound').checked}));
}
for (const id of draftFields) {
  if (id !== 'model' && typeof draft[id] === 'string' && (get(id).tagName !== 'SELECT' || Array.from(get(id).options).some(option=>option.value===draft[id]))) get(id).value = draft[id];
  get(id).addEventListener('input', stash);
}
if (typeof draft.sound === 'boolean') get('sound').checked = draft.sound;
get('sound').addEventListener('change', stash);

function status(message, log) {
  get('status').textContent = message;
  const link = get('log');
  link.hidden = !log;
  if (log) link.href = log;
}
async function api(path, options) {
  const response = await fetch(path, options);
  const type = response.headers.get('content-type') || '';
  const data = type.includes('application/json') ? await response.json() : {};
  if (!response.ok) throw new Error(data.message || 'The local server returned HTTP ' + response.status + '.');
  return data;
}
async function setup() {
  const select = get('model');
  const selected = select.value || draft.model;
  const config = await api('/api/setup');
  token = config.token;
  select.replaceChildren();
  for (const name of config.models) select.add(new Option(name, name));
  if (!config.models.length) select.add(new Option('Start Ollama to load models',''));
  else if (config.models.includes(selected)) select.value = selected;
  else if (config.models.includes('qwen2.5:3b')) select.value = 'qwen2.5:3b';
  get('engine').textContent = (config.models.length ? config.models.length + ' local models' : 'Ollama unavailable') + (config.renderer && config.whisper ? ' · Render ready' : ' · Check setup');
  if (config.voiceKeyAvailable) get('key').placeholder = 'Using environment key unless overridden';
}
async function job(type, envelope) {
  const session = await api('/api/' + type, {
    method:'POST',
    headers:{'Content-Type':'application/json','X-ScriptForge-Token':token},
    body:JSON.stringify(envelope),
  });
  while (true) {
    await new Promise(resolve => setTimeout(resolve, 850));
    const state = await api('/api/jobs/' + session.job);
    status(state.message, state.log);
    if (state.state === 'done') return state.result;
    if (state.state === 'error') {
      const error = new Error(state.message);
      error.log = state.log;
      throw error;
    }
  }
}
function act(id, label, task) {
  const button=get(id);
  button.addEventListener('click', async () => {
    button.disabled=true;
    status(label);
    try { await task(); }
    catch (error) { status(error.message, error.log); }
    finally { button.disabled=false; }
  });
}

function showVoice(item) {
  audio=item;
  const player=get('audio');
  player.src=item.url;
  player.hidden=false;
}
function showExport(item) {
  exportFile=item;
  const link=get('download');
  const video=get('video');
  link.href=item.url;
  link.download=item.filename;
  link.hidden=false;
  video.src=item.url;
  video.hidden=false;
}
if(draft.audio) showVoice(draft.audio);
if(draft.exportFile) showExport(draft.exportFile);

act('refresh','Checking local services…',async () => {await setup();status('Local service status refreshed.');});
function storyParams(mode) {
  return {mode,model:value('model'),topic:value('topic')||value('niche'),niche:value('niche'),length:value('length')};
}
act('ideasBtn','Asking the local model for ideas…',async () => {
  const result = await job('generate',storyParams('ideas'));
  const items = Array.isArray(result.ideas) ? result.ideas.slice(0,10) : [];
  if (!items.length) throw new Error('The model returned no ideas. Try another local model.');
  get('ideas').replaceChildren();
  for (const item of items) {
    const button=document.createElement('button');
    const name=document.createElement('strong');
    const hook=document.createElement('small');
    button.type='button';button.className='idea';
    name.textContent=String(item.title||'Untitled idea');
    hook.textContent=String(item.hook||'');
    button.append(name,hook);
    button.addEventListener('click',()=>{get('topic').value=name.textContent;stash();status('Idea selected. Generate a script when ready.');});
    get('ideas').append(button);
  }
  status(items.length + ' ideas ready.');
});
function showSources() {
  const list = get('sources');
  list.replaceChildren();
  if (!sources.length) return;
  const heading = document.createElement('strong');
  heading.textContent = 'Sources used';
  list.append(heading);
  for (const source of sources) {
    const link = document.createElement('a');
    link.href = source;
    link.textContent = source;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    list.append(link);
  }
}
showSources();
act('scriptBtn','Finding sources before drafting…',async () => {
  const result = await job('generate',storyParams('script'));
  if (typeof result.narration !== 'string' || !result.narration.trim()) throw new Error('The model returned no narration. Try another local model.');
  sources = Array.isArray(result.sources) ? result.sources : [];
  showSources();
  get('title').value=String(result.title||value('topic'));
  get('narration').value=result.narration;
  get('shots').value=JSON.stringify(Array.isArray(result.shots)?result.shots:[],null,2);
  stash();
  status('Draft ready to review and edit.');
});
function showProvider() {
  const provider=value('provider');
  get('windowsFields').hidden=provider!=='piper';
  get('geminiFields').hidden=provider!=='gemini';
  get('elevenFields').hidden=provider!=='elevenlabs';
}
get('provider').addEventListener('change',showProvider);
showProvider();
act('ttsBtn','Preparing voiceover…',async () => {
  const item=await job('tts',{provider:value('provider'),localVoice:value('localVoice'),geminiVoice:value('geminiVoice'),key:value(value('provider')==='gemini'?'geminiKey':'key'),voiceId:value('voiceId'),voiceModel:value('voiceModel'),narration:value('narration')});
  showVoice(item);stash();status('Voiceover ready.');
});
get('upload').addEventListener('change',async event => {
  const file=event.target.files[0];
  if(!file)return;
  status('Importing voiceover…');
  try {
    const item=await api('/api/upload',{method:'POST',headers:{'X-ScriptForge-Token':token,'Content-Type':'application/octet-stream'},body:file});
    showVoice(item);stash();status('Uploaded voiceover ready.');
  } catch(error){status(error.message);}
  finally {event.target.value='';}
});
act('renderBtn','Preparing local render…',async () => {
  if(!audio)throw new Error('Generate or upload a voiceover first.');
  let shots=[];
  if(value('shots')){
    try{shots=JSON.parse(value('shots'));}
    catch{throw new Error('Shot plan must be valid JSON. Clear it to use the fallback scene.');}
    if(!Array.isArray(shots))throw new Error('Shot plan must be a JSON array.');
  }
  const item=await job('render',{audio:audio.id,title:value('title')||value('topic'),shots,style:value('style'),mood:value('mood'),sound:get('sound').checked});
  showExport(item);stash();status('Video ready to preview and download.');
});
setup().catch(error=>status(error.message));
