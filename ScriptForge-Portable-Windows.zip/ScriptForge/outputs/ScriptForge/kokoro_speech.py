"""Generate the local documentary voice with the Kokoro runtime."""
import re
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
from kokoro_onnx import Kokoro


def chunks(text, limit=450):
    text = re.sub(r'<[^>]+>|\[[^\]\n]{1,100}\]', '', text)
    text = re.sub(r'(?m)^\s*[-*#]+\s*', '', text)
    for paragraph in re.split(r'\n\s*\n', text):
        sentences = re.split(r'(?<=[.!?…])\s+', ' '.join(paragraph.split()))
        group = ''
        for sentence in sentences:
            if not sentence:
                continue
            while len(sentence) > limit:
                split = sentence.rfind(' ', 0, limit + 1)
                split = split if split > 0 else limit
                if group:
                    yield group, .13
                    group = ''
                yield sentence[:split], .13
                sentence = sentence[split:].strip()
            if len(group) + len(sentence) + 1 > limit:
                yield group, .13
                group = sentence
            else:
                group = (group + ' ' + sentence).strip()
        if group:
            yield group, .30


def main():
    source, output, model, voices = sys.argv[1:]
    segments = list(chunks(Path(source).read_text(encoding='utf-8')))
    if not segments:
        raise ValueError('No narration remains after removing formatting.')
    engine = Kokoro(model, voices)
    style = engine.get_voice_style('am_michael') * np.float32(.78)
    style += engine.get_voice_style('am_fenrir') * np.float32(.22)
    with sf.SoundFile(output, mode='w', samplerate=24000, channels=1, subtype='PCM_24') as track:
        for text, pause in segments:
            audio, rate = engine.create(text, voice=style, speed=.94, lang='en-us')
            if rate != 24000 or not audio.size:
                raise ValueError('Kokoro returned invalid audio.')
            track.write(audio)
            track.write(np.zeros(round(pause * rate), dtype=np.float32))


if __name__ == '__main__':
    main()
