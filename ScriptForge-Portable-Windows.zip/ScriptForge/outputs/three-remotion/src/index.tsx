import {Composition, registerRoot} from 'remotion';
import {demoProps, ScriptForgeFilm} from './ScriptForgeFilm';

function Root() {
  return <Composition id="ScriptForgeFilm" component={ScriptForgeFilm}
    width={1280} height={720} fps={24} durationInFrames={demoProps.frames}
    defaultProps={demoProps} calculateMetadata={({props}) => ({durationInFrames:props.frames})} />;
}

registerRoot(Root);
