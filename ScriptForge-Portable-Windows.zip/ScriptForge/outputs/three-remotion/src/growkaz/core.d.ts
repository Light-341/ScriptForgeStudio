export function setStyle(id: string): void;
