export function pose(name: string): unknown;
export function breathe(pose: unknown, time: number, amount?: number): unknown;
export function drawFigure(context: CanvasRenderingContext2D, options: Record<string, unknown>): void;
