import {breathe, drawFigure, pose} from './growkaz/rig2d';

export const width = 1280;
export const height = 720;
export const gold = '#eab884';
export const ice = '#a7d9e4';
export const frac = (n: number) => n - Math.floor(n);
export const random = (n: number) => frac(Math.sin(n * 67.239 + 5.63) * 43823.363);
export const clamp = (n: number) => Math.max(0, Math.min(1, n));

type Point = [number, number];
type Ctx = CanvasRenderingContext2D;

function shape(g: Ctx, color: string, points: Point[]) {
  g.fillStyle = color;
  g.beginPath();
  points.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y));
  g.closePath();
  g.fill();
}

function stroke(g: Ctx, color: string, size: number, points: Point[]) {
  g.strokeStyle = color;
  g.lineWidth = size;
  g.lineJoin = 'round';
  g.lineCap = 'round';
  g.beginPath();
  points.forEach(([x, y], i) => i ? g.lineTo(x, y) : g.moveTo(x, y));
  g.stroke();
}

function ellipse(g: Ctx, x: number, y: number, rx: number, ry: number, color: string) {
  g.fillStyle = color;
  g.beginPath();
  g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  g.fill();
}

function gradient(g: Ctx, top: string, middle: string, bottom: string) {
  const fill = g.createLinearGradient(0, 0, 0, height);
  fill.addColorStop(0, top);
  fill.addColorStop(0.55, middle);
  fill.addColorStop(1, bottom);
  g.fillStyle = fill;
  g.fillRect(0, 0, width, height);
}

function glow(g: Ctx, x: number, y: number, r: number, color: string) {
  const fill = g.createRadialGradient(x, y, 0, x, y, r);
  fill.addColorStop(0, color);
  fill.addColorStop(1, '#00000000');
  g.fillStyle = fill;
  g.fillRect(x - r, y - r, 2 * r, 2 * r);
}

function water(g: Ctx, y: number, t: number, rough = false) {
  const wash = g.createLinearGradient(0, y, 0, 720);
  wash.addColorStop(0, rough ? '#3b5367' : '#52747f');
  wash.addColorStop(1, '#17263a');
  g.fillStyle = wash;
  g.fillRect(-170, y, 1620, 720);
  for (let i = 0; i < 86; i++) {
    const x = frac(random(i * 5) + t * (0.003 + random(i + 103) * 0.008)) * 1550 - 130;
    const h = random(i * 5 + 3) * (730 - y);
    const len = 12 + random(i * 5 + 2) * 116 * (h / 460 + 0.12);
    stroke(g, i % 7 ? '#b7e2e626' : '#cbdcdd75', 0.6 + h / 130, [
      [x, y + h], [x + len * 0.6, y + h + Math.sin(t + i) * (rough ? 2.8 : 0.8)], [x + len, y + h],
    ]);
  }
}

function flakes(g: Ctx, t: number, count: number, heavy = false) {
  for (let i = 0; i < count; i++) {
    const speed = random(i * 9 + 3);
    const x = frac(random(i * 9) + t * (heavy ? 0.025 + speed * 0.065 : 0.004 + speed * 0.012)) * width;
    const y = frac(random(i * 9 + 1) + t * (0.021 + speed * 0.045)) * height;
    const size = 0.65 + speed * 2.9;
    if (heavy) stroke(g, '#e5f0ff65', size * 0.7, [[x, y], [x - size * 3.9, y - size * 1.3]]);
    else ellipse(g, x, y, size * 0.69, size * 0.69, '#e7f2ea75');
  }
}

function ship(g: Ctx, x: number, y: number, s: number, rot: number, small = false, damaged = false) {
  g.save();
  g.translate(x, y);
  g.rotate(rot);
  g.scale(s, s);
  const hull: Point[] = [[-205, -17], [-183, -43], [-131, -37], [-105, -28], [117, -34], [176, -57], [225, -57], [188, -12], [153, 21], [-130, 25], [-180, 14]];
  shape(g, damaged ? '#26313a' : '#242530', hull);
  stroke(g, damaged ? '#8799a1' : '#cf9b73', 3, hull.slice(0, 8));
  for (let i = 0; i < 5; i++) stroke(g, '#8d726b75', 1.6, [[-171 + i * 6, -12 + i * 5], [157 - i * 5, -11 + i * 5]]);
  for (let i = 0; i < 9; i++) {
    g.fillStyle = i % 3 === 0 ? '#f0ba83' : '#715743';
    g.fillRect(-130 + i * 29, -21, 9, 7);
  }
  stroke(g, '#514134', 5, [[156, -44], [245, -88]]);
  const masts = small ? [[-4, 188], [110, 137]] : [[-116, 143], [-24, 233], [80, 181]];
  masts.forEach(([mx, mh], i) => {
    const lean = damaged && i % 2 === 0 ? 43 : 10;
    const top = damaged ? mh * (i === 1 ? 0.58 : 0.29) : mh;
    stroke(g, damaged ? '#514e4b' : '#665347', 6, [[mx, -28], [mx - lean, -top]]);
    stroke(g, '#c5b5a25e', 1.4, [[-160, -31], [mx - lean, -top + 6], [166, -32]]);
    if (!damaged) {
      const w = i === 1 ? 62 : 48;
      shape(g, i % 2 ? '#cab390' : '#dad0ad', [[mx - w, -top + 33], [mx + w, -top + 35], [mx + w + 11, -top + 106], [mx - w + 9, -top + 116], [mx - w - 9, -top + 93]]);
      shape(g, '#a89b88', [[mx + 9, -top + 36], [mx + w, -top + 35], [mx + w + 11, -top + 106], [mx + 14, -top + 111]]);
      stroke(g, '#f0e0bb', 1.5, [[mx - w, -top + 32], [mx + w, -top + 34]]);
      if (i === 1) shape(g, '#a95143', [[mx - lean, -top], [mx + 19, -top + 4], [mx + 32, -top + 15], [mx - lean, -top + 12]]);
    }
  });
  g.restore();
}

function rocks(g: Ctx, winter: number) {
  shape(g, '#677985', [[-150, 465], [25, 404], [124, 412], [236, 363], [386, 398], [500, 383], [660, 438], [756, 465], [999, 492], [1440, 539], [1440, 780], [-150, 780]]);
  shape(g, winter > 0.5 ? '#b1c4ce' : '#8e9da6', [[-130, 466], [25, 408], [124, 416], [235, 368], [386, 403], [491, 388], [654, 441], [484, 426], [353, 454], [182, 436], [45, 465], [-140, 506]]);
  shape(g, '#3f525e', [[-150, 570], [14, 532], [155, 550], [300, 527], [450, 564], [660, 540], [875, 574], [1082, 559], [1440, 597], [1440, 770], [-150, 770]]);
  for (let i = 0; i < 62; i++) {
    const x = -75 + random(i * 5 + 612) * 1430;
    const y = 471 + random(i * 5 + 16) * 220;
    const l = 6 + random(i * 5 + 17) * 57;
    shape(g, i % 3 === 0 ? '#bdc7c969' : '#20334260', [[x, y], [x + l * 0.38, y - l * 0.19], [x + l, y], [x + l * 0.78, y + l * 0.09]]);
  }
}

function hut(g: Ctx, x: number, y: number, s: number, build = 1, warm = false, snow = false) {
  g.save();
  g.translate(x, y);
  g.scale(s, s);
  ellipse(g, 14, 6, 206, 26, '#121e2a72');
  if (build < 0.75) {
    for (let i = 0; i < 7; i++) {
      const a = -150 + i * 43;
      const wall = 15 + clamp(build * 1.7 - i * 0.025) * 139;
      stroke(g, '#382d29', 12, [[a, 0], [a, -wall]]);
      stroke(g, '#a48573', 2, [[a - 4, 0], [a - 4, -wall]]);
    }
    for (let i = 0; i < Math.round(build * 19); i++) stroke(g, '#67524b', 8, [[-155, -i * 9], [157, -i * 9]]);
    if (build > 0.36) {
      stroke(g, '#482d21', 13, [[-178, -125], [-24, -222], [177, -123]]);
      stroke(g, '#c2a59a', 3, [[-176, -130], [-24, -225], [175, -128]]);
    }
    g.restore();
    return;
  }
  shape(g, '#514740', [[-154, -123], [-24, -199], [145, -118], [145, 0], [-154, 0]]);
  shape(g, '#342e2c', [[145, -118], [202, -149], [198, -17], [145, 0]]);
  shape(g, '#25292d', [[-177, -123], [-24, -219], [33, -246], [224, -158], [166, -121], [-24, -196]]);
  stroke(g, snow ? '#d4e2e7' : '#a6a0a1', snow ? 10 : 3, [[-178, -124], [-24, -219], [34, -247], [221, -158]]);
  stroke(g, '#c1a795', 2, [[-178, -121], [-24, -211], [167, -120]]);
  for (let i = 0; i < 12; i++) stroke(g, '#211d1b75', 2, [[-153, -i * 10], [145, -i * 10], [196, -i * 10 - 14]]);
  shape(g, '#131925', [[-41, 0], [-41, -93], [14, -99], [14, 0]]);
  stroke(g, '#827168', 3, [[-46, 0], [-46, -96], [14, -102], [19, 0]]);
  if (warm) glow(g, -14, -47, 112, '#ffc47872');
  g.fillStyle = warm ? '#eba66c' : '#181e24';
  g.fillRect(58, -83, 39, 30);
  stroke(g, '#483d37', 3, [[78, -83], [78, -53]]);
  g.restore();
}

function actor(g: Ctx, x: number, y: number, s: number, t: number, options: {look?: -1 | 1; outfit?: string; action?: string; tired?: boolean; seed?: number} = {}) {
  const {look = 1, outfit = '#a45a4d', action = 'stand', tired = false, seed = 0} = options;
  drawFigure(g, {
    x, y, s, facing: look, pose: breathe(pose(action), t + seed, tired ? 0.32 : 0.77),
    expr: tired ? 'worried' : 'neutral', blink: frac(t / 3.1 + seed) > 0.96,
    outfit: {tee: outfit}, rim: {color: '#bbd9df', dir: [-0.62, -0.62], w: 3.4},
  });
}

function shore(g: Ctx, kind: string, t: number, p: number) {
  const snow = kind === 'winter' || kind === 'seasons';
  const winter = kind === 'seasons' ? 0.5 + 0.5 * Math.sin(p * 4.2 * Math.PI - 0.9) : Number(snow);
  const sunset = kind === 'provisions' || kind === 'farewell' || kind === 'empty';
  gradient(g, sunset ? '#34394f' : '#263f58', sunset ? '#b28072' : '#76929e', '#304454');
  glow(g, sunset ? 912 : 330, 346, 380, sunset ? '#f7b87772' : '#c6dfe75c');
  shape(g, '#456070', [[-100, 375], [122, 328], [197, 350], [312, 318], [458, 364], [522, 347], [700, 372], [860, 335], [1020, 371], [1450, 357], [1440, 560], [-130, 560]]);
  water(g, 369, t, kind === 'salvage');
  const scale = kind === 'farewell' ? 1.04 - p * 0.28 : 1.03 + p * 0.07;
  g.save();
  g.translate(width * 0.5 + Math.sin(p * 1.9) * 18, height * 0.55);
  g.scale(scale, scale);
  g.translate(-width * 0.5, -height * 0.55);
  rocks(g, winter);
  if (kind === 'inlet') {
    ship(g, 949, 450, 0.44, -0.03 + Math.sin(t) * 0.026, true, false);
    ship(g, 1118, 454, 0.26, 0.04, false, false);
  } else if (kind === 'salvage') {
    ship(g, 899, 460, 0.67, 0.24 + Math.sin(t * 0.8) * 0.022, false, true);
    ship(g, 1118, 462, 0.34, -0.16, true, true);
    actor(g, 337, 554, 0.62, t, {action: 'holdFront'});
    actor(g, 452, 565, 0.54, t, {action: 'point', seed: 0.75});
    stroke(g, '#997d68', 12, [[362, 462], [540, 508]]);
  } else {
    const building = kind === 'building';
    const empty = kind === 'empty' || kind === 'farewell' || kind === 'discovery';
    const x = kind === 'farewell' ? 622 : 788;
    hut(g, x, 531, kind === 'farewell' ? 0.63 : 1.14, building ? 0.15 + p * 0.83 : 1, !empty && kind !== 'seasons', winter > 0.5);
    if (building) {
      actor(g, 441 + 35 * p, 569, 0.77, t, {action: 'holdFront'});
      actor(g, 640, 556, 0.67, t, {action: 'pointUp', seed: 0.6});
      stroke(g, '#775645', 13, [[467 + 35 * p, 465], [632 + 6 * p, 518]]);
      stroke(g, '#b8997d', 2.7, [[467 + 35 * p, 461], [632 + 6 * p, 514]]);
    }
    if (kind === 'winter' || kind === 'seasons') {
      actor(g, 521, 565, 0.64, t, {action: 'crossArms', tired: true});
      if (kind === 'winter') actor(g, 633, 550, 0.52, t, {look: -1, action: 'crossArms', tired: true, seed: 0.8});
    }
    if (kind === 'provisions') {
      actor(g, 555, 572, 0.76, t, {action: 'holdFront', outfit: '#937149'});
      actor(g, 708, 557, 0.67, t, {look: -1, action: 'holdFront', tired: true});
      ellipse(g, 613, 486, 17, 11, '#ba8958');
      stroke(g, '#ded6a9', 1.9, [[604, 492], [614, 479], [625, 489]]);
    }
    if (kind === 'discovery') actor(g, 562 + p * 35, 565, 0.66, t, {action: 'point', outfit: '#56758a'});
  }
  g.restore();
  if (snow) flakes(g, t, Math.round(47 + 104 * winter), winter > 0.65);
  else flakes(g, t + 2.1, 21);
}

function sailing(g: Ctx, kind: string, t: number, p: number) {
  const storm = kind === 'rough';
  gradient(g, '#24334b', storm ? '#5b697d' : '#a2817d', '#223746');
  glow(g, 212, 364, 350, storm ? '#66809b66' : '#f5b87a78');
  water(g, 365, t, storm);
  if (kind === 'scout' || kind === 'trade') {
    shape(g, '#626c6d', [[-100, 505], [139, 460], [317, 478], [468, 457], [624, 501], [860, 504], [1400, 564], [1400, 760], [-100, 760]]);
    ship(g, 986 - p * 47, 456, 0.46, Math.sin(t) * 0.025, true);
    actor(g, 404, 548, 0.82, t, {outfit: '#9a7654', action: 'holdFront'});
    actor(g, 608, 548, 0.79, t, {outfit: '#537b89', look: -1, action: 'point'});
    if (kind === 'trade') {
      shape(g, '#c3a17d', [[459, 437], [500, 440], [496, 452], [456, 453]]);
      stroke(g, '#e1c8a5', 2, [[459, 437], [500, 440]]);
    }
    return;
  }
  const drift = p * 112;
  ship(g, 382 + drift, 442 + Math.sin(t * 0.85) * 6, 0.79, Math.sin(t * 0.78) * (storm ? 0.09 : 0.025));
  ship(g, 828 + drift * 0.56, 418 + Math.cos(t * 0.85) * 4, 0.52, Math.cos(t * 0.86) * (storm ? 0.076 : 0.024), true);
  for (let i = 0; i < 20; i++) {
    const base = frac(random(i + 130) + t * 0.04);
    const x = base * 1280;
    const y = 452 + random(i + 20) * 80;
    stroke(g, '#d6e5e53c', 2, [[x, y], [x + 42 + 32 * base, y + 1.7]]);
  }
  if (storm) flakes(g, t, 120, true);
}

function mapScene(g: Ctx, kind: string, t: number, p: number) {
  const local = kind === 'mapBay';
  gradient(g, '#122032', '#253b4d', '#101b2b');
  g.save();
  g.translate(24 * p, -9 * p);
  for (let x = 60; x < width; x += 72) stroke(g, '#a9c4c21c', 1, [[x, 62], [x, 652]]);
  for (let y = 82; y < 660; y += 54) stroke(g, '#a9c4c21c', 1, [[45, y], [1200, y]]);
  const northAmerica: Point[] = [[30, 61], [451, 61], [480, 92], [439, 136], [469, 158], [450, 192], [422, 210], [403, 184], [370, 196], [346, 236], [357, 263], [397, 274], [427, 315], [400, 351], [351, 363], [386, 390], [430, 399], [458, 434], [433, 481], [389, 507], [360, 552], [304, 580], [292, 629], [244, 666], [25, 666]];
  const europe: Point[] = [[1260, 72], [1045, 72], [1035, 96], [1058, 120], [1033, 153], [998, 183], [1017, 226], [979, 259], [985, 290], [935, 321], [941, 359], [996, 372], [978, 412], [1003, 463], [1081, 451], [1158, 488], [1247, 509]];
  const greenland: Point[] = [[499, 72], [665, 66], [682, 101], [655, 133], [664, 180], [623, 208], [591, 274], [549, 259], [538, 210], [513, 166]];
  if (local) {
    g.translate(-279, -193);
    g.scale(1.83, 1.83);
  }
  for (const land of [northAmerica, europe, greenland]) {
    shape(g, '#607577', land);
    stroke(g, '#aac5ba91', 1.5, land);
  }
  shape(g, '#91a39c', [[877, 233], [899, 218], [903, 245], [923, 277], [912, 298], [931, 317], [895, 337], [885, 302], [891, 283], [875, 267]]);
  shape(g, '#839990', [[854, 260], [866, 245], [879, 262], [872, 288], [855, 304], [842, 280]]);
  shape(g, '#90b4b2', [[371, 253], [376, 247], [381, 253], [378, 259]]);
  if (!local) {
    const path: Point[] = [[904, 319], [827, 325], [744, 301], [640, 280], [573, 250], [503, 227], [450, 222], [408, 244], [378, 253]];
    const a = clamp(p * 1.5 + 0.05) * (path.length - 1);
    const ix = Math.min(path.length - 2, Math.floor(a));
    const [x0, y0] = path[ix];
    const [x1, y1] = path[ix + 1];
    const marker: Point = [x0 + (x1 - x0) * (a - ix), y0 + (y1 - y0) * (a - ix)];
    g.setLineDash([8, 9]);
    stroke(g, '#ffd098', 3, [...path.slice(0, ix + 1), marker]);
    g.setLineDash([]);
    ellipse(g, marker[0], marker[1], 5.6, 5.6, '#ffe5bb');
  }
  ellipse(g, 378, 253, 4.5 + 2.8 * Math.sin(t * 2) ** 2, 4.5 + 2.8 * Math.sin(t * 2) ** 2, gold);
  g.font = '650 16px system-ui';
  g.fillStyle = '#f1e0c7';
  g.fillText('MARBLE ISLAND', 392, 251);
  if (!local) {
    g.fillText('GRAVESEND', 925, 318);
    g.fillStyle = '#b4cbd3';
    g.font = '550 17px system-ui';
    g.fillText('NORTH ATLANTIC', 625, 474);
  } else {
    g.fillStyle = '#b4cbd3';
    g.font = '550 14px system-ui';
    g.fillText('HUDSON BAY', 381, 292);
  }
  g.restore();
  if (!local) {
    g.save();
    g.translate(1078, 530);
    stroke(g, '#a3beb9', 1.3, [[0, 43], [0, -43]]);
    stroke(g, '#a3beb9', 1.3, [[-43, 0], [43, 0]]);
    shape(g, gold, [[0, -40], [-8, 3], [0, -2], [8, 3]]);
    g.fillStyle = ice;
    g.font = '700 15px system-ui';
    g.fillText('N', -6, -49);
    g.restore();
  }
}

function paper(g: Ctx, kind: string, t: number, p: number) {
  gradient(g, '#181c2a', '#503d38', '#29242c');
  glow(g, 867, 270, 429, '#ed9d5e83');
  g.save();
  const s = 1 + p * 0.095;
  g.translate(644, 356);
  g.scale(s, s);
  g.rotate(-0.07 + p * 0.045);
  shape(g, '#100f17', [[-376, -197], [380, -194], [386, 219], [-379, 214]]);
  shape(g, '#b69d80', [[-359, -207], [7, -195], [348, -210], [358, 186], [2, 201], [-369, 183]]);
  shape(g, '#d5bb91', [[-354, -211], [0, -179], [347, -211], [348, 176], [1, 193], [-358, 172]]);
  shape(g, '#ac9172', [[-7, -179], [11, -180], [13, 193], [0, 192]]);
  for (let i = 0; i < 13; i++) {
    const y = -102 + 19 * i;
    stroke(g, '#8b715c6b', 1, [[-318, y - 12], [-32, y + 5]]);
    stroke(g, '#8b715c6b', 1, [[34, y], [309, y - 9]]);
    if (i < 10) stroke(g, '#82614970', 2, [[-299, y - 19], [-113 + random(i + 812) * 73, y - 10]]);
  }
  g.fillStyle = '#4a382e';
  g.font = '600 23px Georgia';
  g.fillText(kind === 'sources' ? 'Marble Island' : 'Hudson’s Bay Company', -306, -127);
  g.font = '700 38px Georgia';
  g.fillText(kind === 'sources' ? '1769' : '1722', 58, -118);
  g.font = 'italic 28px Georgia';
  g.fillText(kind === 'sources' ? 'Samuel Hearne' : 'Albany', 59, -52);
  g.fillText(kind === 'sources' ? 'Inuit testimony' : 'Discovery', 59, 5);
  if (kind === 'ledger') {
    const across = clamp((p - 0.19) * 2.3);
    stroke(g, '#893e36', 3, [[50, -57], [50 + 166 * across, -53]]);
    stroke(g, '#893e36', 3, [[50, 1], [50 + 188 * across, -6]]);
  }
  g.restore();
  for (let i = 0; i < 16; i++) {
    const x = random(i * 13 + 39) * width + t * (i % 2 ? 2 : -2);
    ellipse(g, x, 150 + random(i * 13 + 41) * 425, 1.2, 1.2, '#e7c89c76');
  }
}

export function drawPlate(g: Ctx, kind: string, time: number, progress: number) {
  if (kind === 'map' || kind === 'mapBay') mapScene(g, kind, time, progress);
  else if (kind === 'ledger' || kind === 'sources') paper(g, kind, time, progress);
  else if (['sail', 'rough', 'trade', 'scout'].includes(kind)) sailing(g, kind, time, progress);
  else shore(g, kind, time, progress);
}
