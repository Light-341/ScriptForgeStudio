import {useMemo} from 'react';
import * as THREE from 'three';
const GOLD = '#ffc17c';
const TEAL = '#83ebe1';
const TAU = Math.PI * 2;
const W = 1280;
const H = 720;
const clamp = (x: number) => Math.max(0, Math.min(1, x));
const hash = (n: number) => (Math.sin(n * 91.392 + 2.74) * 43758.5453) % 1;
const random = (n: number) => (hash(n) + 1) % 1;

export function Dust({count, burst, speed = 1, color}: {count: number; burst?: number; speed?: number; color: string}) {
  const positions = useMemo(() => {
    const array = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const z = random(i * 5 + 2) * 2 - 1;
      const angle = random(i * 5 + 1) * TAU;
      const radial = Math.sqrt(1 - z * z);
      const distance = burst === undefined
        ? 3 + random(i * 5 + 4) * 19
        : 0.6 + burst * (1 + random(i * 5 + 4) * 4) * speed;
      array.set([Math.cos(angle) * radial * distance, Math.sin(angle) * radial * distance, z * distance], i * 3);
    }
    return array;
  }, [count, burst, speed]);

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={burst === undefined ? 0.032 : 0.055} color={color} transparent opacity={burst === undefined ? 0.72 : Math.max(0, 0.92 - burst * 0.49)} depthWrite={false} blending={THREE.AdditiveBlending} />
    </points>
  );
}

export function Star({radius, time, cool = false, glow = true}: {radius: number; time: number; cool?: boolean; glow?: boolean}) {
  const material = useMemo(() => ({
    uniforms: {uTime: {value: 0}, uCool: {value: cool ? 1 : 0}},
    vertexShader: `
      varying vec3 p;
      varying vec3 n;
      varying vec3 v;
      void main() {
        p = position;
        n = normalize(normalMatrix * normal);
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        v = -mv.xyz;
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform float uCool;
      varying vec3 p;
      varying vec3 n;
      varying vec3 v;
      void main() {
        vec3 q = normalize(p);
        float band = sin(q.x * 10.0 + sin(q.y * 9.0 + uTime) * 2.7 + q.z * 7.0);
        float cells = sin(q.y * 26.0 + sin(q.z * 11.0 + uTime * .5) * 3.0) * sin(q.x * 29.0 - q.z * 14.0);
        float rim = pow(1.0 - max(0.0, dot(normalize(n), normalize(v))), 2.5);
        vec3 dark = mix(vec3(.45,.055,.018), vec3(.015,.23,.34), uCool);
        vec3 light = mix(vec3(1.,.57,.22),vec3(.42,.95,1.),uCool);
        float heat = clamp(.52 + band * .22 + cells * .14 + rim * .29,0.,1.);
        gl_FragColor = vec4(mix(dark, light, heat) + rim * .20, 1.);
      }
    `,
  }), [cool]);
  material.uniforms.uTime.value = time;

  return (
    <group scale={radius} rotation={[0.2, time * 0.17, 0.12]}>
      <mesh>
        <sphereGeometry args={[1, 36, 24]} />
        <shaderMaterial args={[material]} />
      </mesh>
      {glow && [1.035, 1.085, 1.15].map((size, i) => (
        <mesh key={size} scale={size}>
          <sphereGeometry args={[1, 24, 16]} />
          <meshBasicMaterial color={cool ? TEAL : GOLD} transparent opacity={[0.065, 0.035, 0.019][i]} depthWrite={false} blending={THREE.AdditiveBlending} />
        </mesh>
      ))}
    </group>
  );
}

export function OrbitRing({radius, color = TEAL, opacity = 0.35}: {radius: number; color?: string; opacity?: number}) {
  return (
    <mesh>
      <torusGeometry args={[radius, 0.009, 6, 80]} />
      <meshBasicMaterial color={color} transparent opacity={opacity} depthWrite={false} />
    </mesh>
  );
}

