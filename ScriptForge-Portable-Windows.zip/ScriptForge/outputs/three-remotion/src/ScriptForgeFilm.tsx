import {ThreeCanvas} from '@remotion/three';
import {useLayoutEffect, useRef} from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Dust, OrbitRing, Star} from './SpaceArt';
import {drawPlate} from './KnightArt';
import {breathe, drawFigure, pose} from './growkaz/rig2d';

export type ScriptForgeProps = {
  title: string;
  frames: number;
  shots: {start: number; style: string; label: string}[];
  captions: {start: number; end: number; text: string}[];
};

export const demoProps: ScriptForgeProps = {
  title: 'ScriptForge Studio',
  frames: 48,
  shots: [{start: 0, style: 'orbit', label: ''}],
  captions: [],
};

import {setStyle} from './growkaz/core';

setStyle('emerald');

const palette = {mint:'#83ebdb', gold:'#ffc58e', cream:'#fff0d9'};
const shoreScenes = ['inlet','salvage','farewell','rough'];

function panel(ctx: CanvasRenderingContext2D, style: string, time: number, index: number) {
  const warm = style === 'reveal' || style === 'conversation';
  const background = ctx.createRadialGradient(580, 334, 40, 580, 334, 770);
  background.addColorStop(0, warm ? '#413547' : '#1e4354');
  background.addColorStop(1, '#0b1427');
  ctx.fillStyle=background;
  ctx.fillRect(0,0,1280,720);
  const highlight = index % 2 ? palette.gold : palette.mint;
  ctx.strokeStyle='#9ed9e325';
  ctx.lineWidth=1;
  ctx.beginPath();
  for(let n=0;n<1280;n+=48){ctx.moveTo(n,0);ctx.lineTo(n,720);}
  for(let n=0;n<720;n+=48){ctx.moveTo(0,n);ctx.lineTo(1280,n);}
  ctx.stroke();
  if(style==='conversation'){
    ctx.fillStyle='#121d2f';ctx.fillRect(0,535,1280,185);
    for (const [x,facing,accent] of [[380,1,palette.mint],[900,-1,palette.gold]] as const){
      drawFigure(ctx,{x,y:550,s:1.25,facing,pose:breathe(pose('explain'),time+x/100,0.77),rim:{color:accent,dir:[-0.6,-0.5]},outfit:{tee:accent}});
    }
    ctx.strokeStyle=highlight;
    ctx.lineWidth=3;
    for(let i=0;i<6;i++){
      const phase=(time*1.2+i/6)%1;
      ctx.beginPath();ctx.arc(600+phase*85,302+Math.sin(time+i)*9,2+i*0.84,0,Math.PI*2);ctx.stroke();
    }
    return;
  }
  ctx.save();
  ctx.translate(640,343);
  if(style==='timeline'){
    ctx.strokeStyle='#b9d0dc';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-400,0);ctx.lineTo(400,0);ctx.stroke();
    const active=Math.floor(time*0.7)%5;
    for(let i=0;i<5;i++){
      ctx.fillStyle=i===active?highlight:'#5c7a91';
      ctx.beginPath();ctx.arc(i*190-380,0,i===active?14:7,0,Math.PI*2);ctx.fill();
      ctx.fillRect(i*190-405,-88-18*(i%2),50,37+18*(i%2));
    }
  } else {
    const pulse=(time*0.24)%1;
    const nodeCount=style==='lab'?7:5;
    for(let i=0;i<nodeCount;i++){
      const a=i*Math.PI*2/nodeCount+time*0.13;
      const r=style==='reveal'?181+22*Math.sin(time*0.6):176;
      const x=r*Math.cos(a), y=r*0.77*Math.sin(a);
      ctx.strokeStyle='#a8e4e778';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(x,y);ctx.stroke();
      ctx.fillStyle=highlight;ctx.beginPath();ctx.arc(x,y,7+(i%3)*3,0,Math.PI*2);ctx.fill();
    }
    ctx.fillStyle=highlight;ctx.beginPath();ctx.arc(0,0,24+5*Math.sin(time*2),0,Math.PI*2);ctx.fill();
    ctx.globalAlpha=(1-pulse)*0.72;ctx.strokeStyle=highlight;ctx.lineWidth=2;
    ctx.beginPath();ctx.arc(0,0,39+pulse*166,0,Math.PI*2);ctx.stroke();
  }
  ctx.restore();
}
function Surface({style, elapsed, index}: {style: string; elapsed: number; index: number}) {
  const ref = useRef<HTMLCanvasElement>(null);
  useLayoutEffect(() => {
    const ctx = ref.current?.getContext('2d');
    if (!ctx) return;
    ctx.save();
    if(style==='wreck') drawPlate(ctx, shoreScenes[index % shoreScenes.length], elapsed, Math.min(1,elapsed/14));
    else panel(ctx,style,elapsed,index);
    ctx.restore();
  }, [style, elapsed, index]);
  return <canvas ref={ref} width={1280} height={720} />;
}

export function ScriptForgeFilm({title, captions, shots}: ScriptForgeProps) {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const seconds = frame / fps;
  const index = Math.max(0, shots.findIndex((_, n) => shots[n+1] === undefined || shots[n+1].start>seconds));
  const shot = shots[index] ?? demoProps.shots[0];
  const elapsed = seconds-shot.start;
  const active = captions.find(({start,end}) => start<=seconds && seconds<end);
  return (
    <AbsoluteFill style={{color:palette.cream,background:'radial-gradient(ellipse at 51% 42%,#283353,#0b1124 75%)'}}>
      {shot.style==='orbit' ? (
        <ThreeCanvas width={width} height={height} dpr={1} camera={{position:[0,0,6.4],fov:45}}>
          <group rotation={[0,elapsed*0.04,0]}><Dust count={380} color="#a6bfdb"/></group>
          <group position={[0,0.15,0]} rotation={[0.48,0.35,elapsed*0.12]}>
            <OrbitRing radius={1.9} />
            <OrbitRing radius={2.25} color={palette.gold} opacity={0.23} />
            <Star radius={0.94} time={elapsed} cool={index % 2 !== 0} />
            <group position={[Math.cos(elapsed*0.8)*1.9,Math.sin(elapsed*0.8)*1.9,0]}>
              <Star radius={0.25} time={elapsed} cool={index % 2 === 0} />
            </group>
          </group>
        </ThreeCanvas>
      ) : <Surface key={index} style={shot.style} elapsed={elapsed} index={index} />}
      <AbsoluteFill style={{boxShadow:'inset 0 25px #060d17,inset 0 -25px #060d17',background:'radial-gradient(ellipse,transparent 38%,#050a1778 100%)'}}/>
      {seconds<4 ? (
        <div style={{position:'absolute',top:57,left:62,maxWidth:900,font:'800 43px/1.06 system-ui',textShadow:'0 4px 18px #040913'}}>{title}</div>
      ) : shot.label && (
        <div style={{position:'absolute',top:55,left:62,padding:'7px 13px',borderLeft:'3px solid currentColor',background:'#091522e3',color:palette.mint,letterSpacing:2,font:'700 19px system-ui'}}>{shot.label}</div>
      )}
      {active && (
        <div style={{position:'absolute',left:0,right:0,bottom:50,display:'flex',justifyContent:'center'}}>
          <span style={{background:'#080e1bed',borderRadius:8,padding:'8px 16px 9px',font:'650 35px system-ui',maxWidth:1090,textAlign:'center'}}>{active.text}</span>
        </div>
      )}
    </AbsoluteFill>
  );
}

