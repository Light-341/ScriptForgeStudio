import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {Config} from '@remotion/cli/config';

Config.setChromiumOpenGlRenderer('angle');
Config.setConcurrency(2);

const programFiles = process.env.ProgramFiles;
if (process.platform === 'win32' && programFiles) {
  const chrome = join(programFiles, 'Google', 'Chrome', 'Application', 'chrome.exe');
  if (existsSync(chrome)) {
    Config.setBrowserExecutable(chrome);
  }
}
