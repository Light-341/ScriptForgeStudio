@echo off
setlocal
cd /d "%~dp0"
set "SF_PY=.runtime\python\python.exe"
if exist "%SF_PY%" goto launch
echo Setting up portable Python. Internet access is needed on first launch.
if not exist ".runtime" mkdir ".runtime"
curl.exe --fail --location --retry 2 --output ".runtime\python.zip.part" "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip"
if errorlevel 1 goto failed
powershell.exe -NoProfile -NonInteractive -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::ExtractToDirectory((Resolve-Path '.runtime/python.zip.part').Path, [IO.Path]::GetFullPath('.runtime/python-stage')); Move-Item -LiteralPath '.runtime/python-stage' -Destination '.runtime/python' -ErrorAction Stop"
if errorlevel 1 goto failed
del ".runtime\python.zip.part"
:launch
"%SF_PY%" portable.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Setup did not complete. Review the message above and run this launcher again.
pause
exit /b 1
